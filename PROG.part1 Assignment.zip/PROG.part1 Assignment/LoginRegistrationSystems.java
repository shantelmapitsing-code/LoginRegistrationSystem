

package com.mycompany.loginregistrationsystems;
import java.util.Scanner;
/**
 *
 * @author shant
 */
public class LoginRegistrationSystems {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
    System.out.println("\n===registration===");
  
  //---registration phase---
// user's detail
String firstName;
String lastName;
String userName;
String  password;
String cellPhoneNumber;

System.out.print("Enter  first name: ");
firstName = input.nextLine();

System.out.print("Enter last name: ");
lastName = input.nextLine();

System.out.print("Enter username: ");
userName = input.nextLine();

//username validation
 if(userName.length()<=5 && userName.contains ("_")) {
 
 }else{    
      System.out.println("username is not correctly formatted ; ensure that it contains underscore: ");
}

System.out.print("Enter password: ");
password = input.nextLine();

// regex
String regex = "^(?=.*[a-zA-Z]) (?=.*\\d) (?=.*[@$!%*?&]).{8,}$";
 if(password.matches(regex)){
     System.out.println("Welcome! it is great to see you." );
 }else{
     System.out.println("password is not correctly formatted please make sure it contains required details");
 }     

System.out.print("Enter cellphone number: ");
cellPhoneNumber = input.nextLine();

//cellphone number validation
if(cellPhoneNumber.matches("^\\+27\\d{9}$")) {
}else{
   System.out.println("cell phone number does not contain international code");
   
   System.out.print("\n ===Login===");
 // user's details

System.out.print("Enter username: ");
System.out.println("username must contain underscore and characters<=5 ");
userName = input.nextLine();

System.out.print("Enter password: ");
System.out.println("password must have at least 8 characters, contain a capital letter, a number and special character ");
password = input.nextLine();
   
}
} 
}	


